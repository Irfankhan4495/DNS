package DCN2.example.DCN2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Dcn2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
