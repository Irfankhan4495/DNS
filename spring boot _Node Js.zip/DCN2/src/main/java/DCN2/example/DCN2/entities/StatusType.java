package DCN2.example.DCN2.entities;
 
public enum StatusType {
    PENDING,
    ORDERED,
    CANCELLED;
}
