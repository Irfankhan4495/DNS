package DCN2.example.DCN2.services;

import DCN2.example.DCN2.dao.CartItemRepository;
import DCN2.example.DCN2.dao.CartRepository;
import DCN2.example.DCN2.dao.CustomerRepository;
import DCN2.example.DCN2.entities.Cart;
import DCN2.example.DCN2.entities.CartItem;
import DCN2.example.DCN2.entities.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Set;
import java.util.UUID;

@Service
public class CheckoutServiceImpl implements CheckoutService {

	@Autowired
	private CustomerRepository customerRepository;

	@Autowired
	private CartRepository cartRepository;

	@Autowired
	private CartItemRepository cartItemRepository;

	@Override
	public PurchaseResponse placeOrder(Purchase purchase) {
		// Extract data from Purchase object
		Customer customer = purchase.getCustomer();
		Cart cart = purchase.getCart();
		Set<CartItem> cartItems = purchase.getCartItems();

		// Save customer to the database
		Customer savedCustomer = customerRepository.save(customer);

		// Associate the cart with the customer and save it
		cart.setCustomer(savedCustomer);
		Cart savedCart = cartRepository.save(cart);

		// Associate each cart item with the cart and save them
		for (CartItem cartItem : cartItems) {
			cartItem.setCart(savedCart);
			cartItemRepository.save(cartItem);
		}

		// Generate an order tracking number
		String orderTrackingNumber = generateOrderTrackingNumber();

		// Return the response
		return new PurchaseResponse(orderTrackingNumber);
	}

	private String generateOrderTrackingNumber() {
		return UUID.randomUUID().toString();
	}
}
