package DCN2.example.DCN2;

import DCN2.example.DCN2.dao.CustomerRepository;
import DCN2.example.DCN2.entities.Customer;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
public class DataLoader implements CommandLineRunner {

	private final CustomerRepository customerRepository;

	public DataLoader(CustomerRepository customerRepository) {
		this.customerRepository = customerRepository;
	}

	@Override
	public void run(String... args) {
		// Check if customers already exist
		if (customerRepository.count() == 0) {
			// Add sample customers
			addSampleCustomers();
		}
	}

	private void addSampleCustomers() {
		Customer customer1 = new Customer();
		customer1.setFirstName("John");
		customer1.setLastName("Doe");
		customer1.setAddress("123 Main St");
		customer1.setPostalCode("12345");
		customer1.setPhone("+1234567890");
		customer1.setCreateDate(new Date());
		customer1.setLastUpdate(new Date());

		Customer customer2 = new Customer();
		customer2.setFirstName("Jane");
		customer2.setLastName("Smith");
		customer2.setAddress("456 Oak Ave");
		customer2.setPostalCode("67890");
		customer2.setPhone("+9876543210");
		customer2.setCreateDate(new Date());
		customer2.setLastUpdate(new Date());

		Customer customer3 = new Customer();
		customer3.setFirstName("Alice");
		customer3.setLastName("Johnson");
		customer3.setAddress("789 Pine Rd");
		customer3.setPostalCode("11223");
		customer3.setPhone("+1928374655");
		customer3.setCreateDate(new Date());
		customer3.setLastUpdate(new Date());

		Customer customer4 = new Customer();
		customer4.setFirstName("Bob");
		customer4.setLastName("Brown");
		customer4.setAddress("321 Maple St");
		customer4.setPostalCode("44556");
		customer4.setPhone("+1029384756");
		customer4.setCreateDate(new Date());
		customer4.setLastUpdate(new Date());

		Customer customer5 = new Customer();
		customer5.setFirstName("Charlie");
		customer5.setLastName("Davis");
		customer5.setAddress("654 Cedar Ln");
		customer5.setPostalCode("77889");
		customer5.setPhone("+5647382910");
		customer5.setCreateDate(new Date());
		customer5.setLastUpdate(new Date());

		// Save customers to the repository
		customerRepository.save(customer1);
		customerRepository.save(customer2);
		customerRepository.save(customer3);
		customerRepository.save(customer4);
		customerRepository.save(customer5);
	}
}
