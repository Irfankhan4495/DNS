package DCN2.example.DCN2.dao;

import DCN2.example.DCN2.entities.CartItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CartItemRepository extends JpaRepository<CartItem, Long> {
    // You can define custom query methods here if necessary
}
