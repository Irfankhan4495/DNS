package DCN2.example.DCN2.controllers;

import DCN2.example.DCN2.services.CheckoutService;
import DCN2.example.DCN2.services.Purchase;
import DCN2.example.DCN2.services.PurchaseResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/checkout")
@CrossOrigin("http://localhost:4200") // Allows requests from Angular front-end
public class CheckoutController {

    @Autowired
    private CheckoutService checkoutService;

    /**
     * Endpoint to place an order.
     * 
     * @param purchase The purchase object containing customer, cart, and cart items.
     * @return ResponseEntity containing the PurchaseResponse and HTTP status.
     */
    @PostMapping("/place-order")
    public ResponseEntity<PurchaseResponse> placeOrder(@Valid @RequestBody Purchase purchase) {
        // Process the purchase using the service layer
        PurchaseResponse purchaseResponse = checkoutService.placeOrder(purchase);

        // Return the response with an HTTP OK status
        return new ResponseEntity<>(purchaseResponse, HttpStatus.OK);
    }
}
