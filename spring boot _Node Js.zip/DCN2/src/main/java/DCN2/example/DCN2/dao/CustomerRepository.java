package DCN2.example.DCN2.dao;
 

import DCN2.example.DCN2.entities.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.web.bind.annotation.CrossOrigin;

@CrossOrigin("http://localhost:4200") // Enable Angular compatibility
public interface CustomerRepository extends JpaRepository<Customer, Long> {
}
