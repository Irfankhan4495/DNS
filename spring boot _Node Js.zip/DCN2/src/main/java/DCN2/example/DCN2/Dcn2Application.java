package DCN2.example.DCN2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Dcn2Application {

	public static void main(String[] args) {
		SpringApplication.run(Dcn2Application.class, args);
	}

}
