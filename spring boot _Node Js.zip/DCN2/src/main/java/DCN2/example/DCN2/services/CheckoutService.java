package DCN2.example.DCN2.services;

public interface CheckoutService {
    PurchaseResponse placeOrder(Purchase purchase);
}
